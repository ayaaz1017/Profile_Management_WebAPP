const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());


// MongoDB connection
mongoose.connect('mongodb://localhost:27017/profiles', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });
  const ProfileSchema = new mongoose.Schema({
    name: String,
    photo: String,
    description: String,
    address: String,
    lat: Number,
    lng: Number,
    contact: String,
    interests: [String],
  });
  const Profile = mongoose.model('Profile', ProfileSchema);
  
// Routes
app.get('/profiles', async (req, res) => {
  const profiles = await Profile.find();
  res.json(profiles);
});

app.post('/profiles', async (req, res) => {
  const newProfile = new Profile(req.body);
  await newProfile.save();
  res.json(newProfile);
});

app.put('/profiles/:id', async (req, res) => {
  const updatedProfile = await Profile.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updatedProfile);
});

app.delete('/profiles/:id', async (req, res) => {
  await Profile.findByIdAndDelete(req.params.id);
  res.json({ message: 'Profile deleted' });
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));