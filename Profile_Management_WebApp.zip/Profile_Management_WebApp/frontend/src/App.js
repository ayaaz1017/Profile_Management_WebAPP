import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import ProfileList from './components/ProfileList';
import AdminDashboard from './components/AdminDashboard';

const App = () => (
  <Router>
    <Switch>
      <Route path="/" exact component={ProfileList} />
      <Route path="/admin" component={AdminDashboard} />
    </Switch>
  </Router>
);

export default App;