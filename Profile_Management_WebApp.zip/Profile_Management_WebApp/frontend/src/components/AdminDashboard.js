import React, { useState, useEffect } from 'react';

const AdminDashboard = () => {
  const [profiles, setProfiles] = useState([]);
  const [formData, setFormData] = useState({
    name: '',
    photo: '',
    description: '',
    address: '',
    lat: '',
    lng: '',
    contact: '',
    interests: '',
  });

  useEffect(() => {
    fetch('http://localhost:5000/profiles')
      .then((res) => res.json())
      .then((data) => setProfiles(data));
  }, []);

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch('http://localhost:5000/profiles', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    })
      .then((res) => res.json())
      .then((newProfile) => setProfiles([...profiles, newProfile]));
  };

  const handleDelete = (id) => {
    fetch(`http://localhost:5000/profiles/${id}`, { method: 'DELETE' })
      .then(() => setProfiles(profiles.filter((profile) => profile._id !== id)));
  };

  return (
    <div>
      <h2>Admin Dashboard</h2>
      <form onSubmit={handleSubmit}>
        <input name="name" placeholder="Name" onChange={handleInputChange} required />
        <input name="photo" placeholder="Photo URL" onChange={handleInputChange} required />
        <input name="description" placeholder="Description" onChange={handleInputChange} required />
        <input name="address" placeholder="Address" onChange={handleInputChange} required />
        <input name="lat" placeholder="Latitude" onChange={handleInputChange} required />
        <input name="lng" placeholder="Longitude" onChange={handleInputChange} required />
        <input name="contact" placeholder="Contact" onChange={handleInputChange} required />
        <input name="interests" placeholder="Interests (comma-separated)" onChange={handleInputChange} required />
        <button type="submit">Add Profile</button>
      </form>
      <ul>
        {profiles.map((profile) => (
          <li key={profile._id}>
            {profile.name}
            <button onClick={() => handleDelete(profile._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminDashboard;