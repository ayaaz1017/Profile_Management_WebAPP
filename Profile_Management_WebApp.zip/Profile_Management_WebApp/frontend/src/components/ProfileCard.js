import React from 'react';

const ProfileCard = ({ profile, onSummary }) => (
  <div style={{ border: '1px solid #ccc', margin: '10px', padding: '10px' }}>
    <img src={profile.photo} alt={profile.name} style={{ width: '100px', height: '100px' }} />
    <h3>{profile.name}</h3>
    <p>{profile.description}</p>
    <button onClick={onSummary}>Summary</button>
  </div>
);

export default ProfileCard;