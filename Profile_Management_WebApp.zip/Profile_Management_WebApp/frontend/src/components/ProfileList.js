import React, { useState, useEffect } from 'react';
import ProfileCard from './ProfileCard';
import Map from './Map';

const ProfileList = () => {
  const [profiles, setProfiles] = useState([]);
  const [selectedProfile, setSelectedProfile] = useState(null);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetch('http://localhost:5000/profiles')
      .then((res) => res.json())
      .then((data) => setProfiles(data));
  }, []);

  const filteredProfiles = profiles.filter((profile) =>
    profile.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <input
        type="text"
        placeholder="Search profiles"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
      <div style={{ display: 'flex' }}>
        <div style={{ width: '50%' }}>
          {filteredProfiles.map((profile) => (
            <ProfileCard
              key={profile._id}
              profile={profile}
              onSummary={() => setSelectedProfile(profile)}
            />
          ))}
        </div>
        <div style={{ width: '50%' }}>
          <Map profile={selectedProfile} />
        </div>
      </div>
    </div>
  );
};

export default ProfileList;